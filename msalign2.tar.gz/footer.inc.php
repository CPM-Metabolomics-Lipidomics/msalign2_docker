<?PHP

$footer = "</BODY>\n";
$footer .= "</HTML>";

?>
