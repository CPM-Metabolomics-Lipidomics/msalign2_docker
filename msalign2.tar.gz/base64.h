#ifndef _RAMPBASE64_H
#define _RAMPBASE64_H
#ifdef __cplusplus
extern "C" {
#endif

void b64_decode_mio (char *dest, char *src);

#ifdef __cplusplus
}
#endif
#endif /* BASE64_H */
